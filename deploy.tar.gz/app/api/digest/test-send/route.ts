/**
 * API: Test Send Weekly Digest
 * 
 * Owner/Admin can trigger test digest send to themselves
 * POST /api/digest/test-send
 * Body: { orgId }
 */

import { NextRequest, NextResponse } from 'next/server';
import { createAdminServer } from '@/lib/server/supabaseServer';
import { generateWeeklyDigest } from '@/lib/services/weeklyDigestService';
import { formatDigestForTelegram } from '@/lib/templates/weeklyDigest';
import { sendDigestDM } from '@/lib/services/telegramNotificationService';
import { logAdminAction, AdminActions, ResourceTypes } from '@/lib/logAdminAction';
import { createAPILogger } from '@/lib/logger';
import { getUnifiedUser } from '@/lib/auth/unified-auth';

export async function POST(request: NextRequest) {
  const logger = createAPILogger(request, { endpoint: '/api/digest/test-send' });
  let orgId: string | undefined;
  try {
    const adminSupabase = createAdminServer();
    const body = await request.json();
    orgId = body.orgId;

    if (!orgId) {
      return NextResponse.json({ error: 'orgId required' }, { status: 400 });
    }

    // Check authentication via unified auth
    const user = await getUnifiedUser();
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check permissions (owner/admin only)
    const { data: membership } = await adminSupabase
      .from('memberships')
      .select('role')
      .eq('org_id', orgId)
      .eq('user_id', user.id)
      .single();

    if (!membership || !['owner', 'admin'].includes(membership.role)) {
      return NextResponse.json({ error: 'Forbidden: owner/admin only' }, { status: 403 });
    }

    // Get user's tg_user_id using admin client to bypass RLS
    const { data: participant } = await adminSupabase
      .from('participants')
      .select('tg_user_id')
      .eq('org_id', orgId)
      .eq('user_id', user.id)
      .single();

    if (!participant?.tg_user_id) {
      return NextResponse.json({
        error: 'No Telegram account linked',
        message: 'Вы должны связать Telegram аккаунт, чтобы получать дайджесты.'
      }, { status: 400 });
    }

    // Check if bot token is configured
    if (!process.env.TELEGRAM_NOTIFICATIONS_BOT_TOKEN) {
      return NextResponse.json({
        error: 'Bot not configured',
        message: 'TELEGRAM_NOTIFICATIONS_BOT_TOKEN не настроен на сервере.'
      }, { status: 500 });
    }

    // Generate digest
    const startTime = Date.now();
    const digest = await generateWeeklyDigest(orgId, user.id);
    const digestText = formatDigestForTelegram(digest);

    // Send via Telegram
    const sendResult = await sendDigestDM(participant.tg_user_id, digestText);

    if (!sendResult.success) {
      return NextResponse.json({
        error: 'Failed to send',
        message: sendResult.error || 'Не удалось отправить сообщение в Telegram',
        hint: sendResult.error?.includes('not started')
          ? 'Запустите бота уведомлений Orbo в Telegram (отправьте /start)'
          : undefined
      }, { status: 500 });
    }

    const duration = Date.now() - startTime;

    // Log admin action
    await logAdminAction({
      orgId,
      userId: user.id,
      action: AdminActions.SEND_TEST_DIGEST,
      resourceType: ResourceTypes.DIGEST,
      metadata: {
        recipient_tg_user_id: participant.tg_user_id,
        cost_usd: digest.cost.totalUsd,
        messages_count: digest.keyMetrics.current.messages,
        duration_ms: duration
      },
      requestId: request.headers.get('x-vercel-id') || undefined
    });

    return NextResponse.json({
      success: true,
      messageId: sendResult.messageId,
      cost: {
        usd: digest.cost.totalUsd,
        rub: digest.cost.totalRub
      },
      stats: {
        messages: digest.keyMetrics.current.messages,
        participants: digest.keyMetrics.current.active_participants,
        topContributors: digest.topContributors.length,
        events: digest.upcomingEvents.length
      },
      durationMs: duration
    });

  } catch (error) {
    logger.error({ 
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      org_id: orgId || 'unknown'
    }, 'Test digest send error');
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

