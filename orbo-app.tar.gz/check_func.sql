SELECT prosrc FROM pg_proc WHERE proname = 'get_qualification_summary';
