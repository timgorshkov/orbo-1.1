SELECT get_event_registered_count('2f7972fd-3d02-41dc-b3c7-140bace99966'::uuid, false);
SELECT pg_typeof(get_event_registered_count('2f7972fd-3d02-41dc-b3c7-140bace99966'::uuid, false));
