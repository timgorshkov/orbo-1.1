# Спецификация: Анонсы (Массовые публикации в группы)

## Обзор

Функциональность для массовой рассылки сообщений в подключенные Telegram-группы организации:
- Ручные анонсы по расписанию
- Автоматически создаваемые анонсы для событий (за 24ч и 1ч)
- Календарь запланированных публикаций
- Архив отправленных сообщений

## База данных

### Таблица `announcements`

```sql
CREATE TABLE announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  
  -- Контент
  title VARCHAR(255) NOT NULL,           -- Заголовок (для UI, не отправляется)
  content TEXT NOT NULL,                  -- Текст с Telegram Markdown
  
  -- Связь с событием (опционально)
  event_id UUID REFERENCES events(id) ON DELETE SET NULL,
  reminder_type VARCHAR(50),              -- '24h', '1h', NULL для ручных
  
  -- Целевые группы
  target_groups UUID[] NOT NULL,          -- Массив ID групп
  
  -- Расписание
  scheduled_at TIMESTAMPTZ NOT NULL,      -- Когда отправить
  sent_at TIMESTAMPTZ,                    -- Когда отправлено
  
  -- Статус
  status VARCHAR(20) DEFAULT 'scheduled', -- scheduled, sending, sent, failed, cancelled
  
  -- Авторство
  created_by UUID REFERENCES auth.users(id),
  created_by_name VARCHAR(255),           -- Имя автора или "автоматически"
  updated_by UUID REFERENCES auth.users(id),
  updated_by_name VARCHAR(255),           -- Имя последнего редактора
  
  -- Метаданные
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Результаты отправки
  send_results JSONB                      -- {group_id: {success: bool, message_id, error}}
);

CREATE INDEX idx_announcements_org ON announcements(org_id);
CREATE INDEX idx_announcements_scheduled ON announcements(scheduled_at) WHERE status = 'scheduled';
CREATE INDEX idx_announcements_event ON announcements(event_id) WHERE event_id IS NOT NULL;
```

## API Endpoints

### GET /api/announcements?org_id=...&status=...&from=...&to=...
Список анонсов с фильтрацией

### POST /api/announcements
Создать новый анонс

### GET /api/announcements/[id]
Получить детали анонса

### PATCH /api/announcements/[id]
Редактировать анонс (обновляет updated_by_name)

### DELETE /api/announcements/[id]
Удалить анонс (только scheduled)

### POST /api/announcements/[id]/send
Отправить анонс немедленно

## Cron Job

`/api/cron/send-announcements` - каждую минуту проверяет и отправляет запланированные анонсы

## UI Компоненты

### Страница /p/[org]/announcements

1. **Вкладки:**
   - Календарь (по умолчанию)
   - Список (таблица с фильтрами)
   - Архив (отправленные)

2. **Календарь:**
   - Месячный вид
   - Дни с анонсами выделены
   - Клик на день → список анонсов дня

3. **Форма создания/редактирования:**
   - Заголовок (для UI)
   - Контент с Telegram Markdown preview
   - Выбор групп (мультиселект)
   - Дата и время отправки
   - Связь с событием (опционально)

4. **Карточка анонса:**
   - Статус (цветной бейдж)
   - Заголовок и превью текста
   - Целевые группы
   - Автор / Последний редактор
   - Действия: редактировать, отправить сейчас, удалить

## Автосоздание анонсов для событий

При создании события:
1. Если дата события > текущее время + 24ч → создать анонс за 24ч
2. Если дата события > текущее время + 1ч → создать анонс за 1ч
3. `created_by_name = "автоматически"`
4. `reminder_type = "24h"` или `"1h"`
5. `event_id = id события`

Шаблон текста:
```
🗓 Напоминание: {название события}

📅 {дата и время}
📍 {место, если есть}

{описание события}
```

## Telegram Markdown

Поддерживаемое форматирование:
- **жирный** → `*жирный*`
- _курсив_ → `_курсив_`
- ~~зачёркнутый~~ → `~зачёркнутый~`
- `код` → `` `код` ``
- [ссылка](url) → `[ссылка](url)`
- Emoji: стандартные Unicode

## Авторство

- При создании: `created_by_name` = имя пользователя или "автоматически"
- При редактировании: `updated_by_name` = имя редактора
- Отображение в UI: "Автор: {created_by_name}" и если отличается "Изменил: {updated_by_name}"

