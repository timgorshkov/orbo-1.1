# 📋 План работ на 5 декабря 2025

**Статус:** Готов к выполнению  
**Оценка времени:** 6-8 часов  
**Приоритет:** Исправление AI-анализа → Улучшение качества → Логгирование → Unisender Go

---

## 🔴 Задача 1: Исправить баг AI-анализа (2-3 часа)

### Проблема
При нажатии кнопки AI-анализа для участника с десятками сообщений во вкладке Активность, система показывает "0 сообщений доступно для анализа".

### Причина
Фильтрация `activity_events` по `org_id` вместо `tg_chat_id` групп организации. Сообщения записываются с `org_id` первой организации, которая получила webhook, но не дублируются для других организаций.

### Файлы для изменения

#### 1. `lib/services/participantEnrichmentService.ts`

**Строка ~85-91 (функция `enrichParticipant`):**
```typescript
// БЫЛО:
const { data: messages, error: messagesError } = await supabaseAdmin
  .from('activity_events')
  .select('id, tg_user_id, message_id, event_type, created_at, meta')
  .eq('org_id', orgId)  // ❌ ПРОБЛЕМА
  .eq('event_type', 'message')
  ...

// НУЖНО:
// 1. Сначала получить tg_chat_id групп организации
const { data: orgGroups } = await supabaseAdmin
  .from('org_telegram_groups')
  .select('tg_chat_id')
  .eq('org_id', orgId)

const chatIds = (orgGroups || []).map(g => g.tg_chat_id)

// 2. Фильтровать по tg_chat_id вместо org_id
const { data: messages, error: messagesError } = await supabaseAdmin
  .from('activity_events')
  .select('id, tg_user_id, tg_chat_id, message_id, event_type, created_at, meta')
  .in('tg_chat_id', chatIds)  // ✅ ИСПРАВЛЕНИЕ
  .eq('event_type', 'message')
  ...
```

**Строка ~100-107 (загрузка реакций):**
```typescript
// Аналогично исправить:
.in('tg_chat_id', chatIds)  // вместо .eq('org_id', orgId)
```

**Строка ~555-562 (функция `estimateEnrichmentCost`):**
```typescript
// Аналогично исправить:
// 1. Получить chatIds
// 2. Использовать .in('tg_chat_id', chatIds)
```

**Строка ~310-320 (функция `calculateActivityStats`):**
```typescript
// Проверить и исправить если есть фильтрация по org_id
```

### Тестирование
1. Открыть профиль участника с сообщениями во вкладке Активность
2. Нажать кнопку AI-анализа
3. Проверить что `messageCount` > 0 в ответе API
4. Убедиться что анализ выполняется

---

## 🟡 Задача 2: Улучшить качество AI-анализа (2-3 часа)

### Цель
Сделать анализ более качественным за счёт добавления контекста для коротких сообщений.

### Подходы к реализации

#### A. Контекст ответов (reply_to)
**Файл:** `lib/services/participantEnrichmentService.ts`

**Что делать:**
1. При подготовке сообщений для AI, для каждого сообщения с `reply_to_message_id`:
   - Найти оригинальное сообщение в `participant_messages`
   - Включить его текст как контекст

**Структура данных для AI:**
```typescript
interface MessageWithContext {
  text: string;              // Текст сообщения участника
  created_at: string;
  reply_to_text?: string;    // ⭐ NEW: Текст сообщения, на которое отвечает
  reply_to_author?: string;  // ⭐ NEW: Автор оригинального сообщения
}
```

**Изменения в промпте:**
```
Сообщения участника могут содержать контекст ответа:
- ➡️ - сообщение участника
- ↩️ - сообщение, на которое участник отвечал (для контекста)
```

#### B. Контекст треда (2-3 сообщения до/после)
**Файл:** `lib/services/participantEnrichmentService.ts`

**Что делать:**
1. Для каждого сообщения участника, загрузить ±2 сообщения по времени в той же группе
2. Использовать `message_thread_id` если есть (топики)

**Структура данных:**
```typescript
interface MessageWithContext {
  text: string;
  created_at: string;
  reply_to_text?: string;
  thread_context?: string[];  // ⭐ NEW: 2-3 сообщения до/после
}
```

#### C. Реакции как сигнал интересов
**Файл:** `lib/services/participantEnrichmentService.ts`

**Что делать:**
1. Загрузить сообщения, на которые участник ставил реакции
2. Извлечь темы/ключевые слова из этих сообщений
3. Добавить в промпт как дополнительный сигнал

**Изменения в промпте:**
```
Дополнительный контекст - сообщения, которые понравились участнику (реакции):
🔥 "Текст сообщения 1..."
👍 "Текст сообщения 2..."

Используй эти сообщения как дополнительный сигнал об интересах участника.
```

### Порядок реализации
1. **A (reply_to)** — самый важный контекст
2. **C (реакции)** — быстро реализуется, хороший сигнал
3. **B (тред)** — если останется время

### Файлы для изменения
- `lib/services/participantEnrichmentService.ts` — подготовка данных
- `lib/services/enrichment/openaiService.ts` — обновление промпта

---

## 🟢 Задача 3: Логгирование критических ошибок (если останется время)

### Scope (MVP)
Создать базовую инфраструктуру для логирования ошибок в интерфейс суперадминов.

### Файлы для создания/изменения

#### 1. Миграция: `db/migrations/136_admin_error_logs.sql`
```sql
CREATE TABLE public.admin_error_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- Категоризация
  category TEXT NOT NULL, -- 'auth', 'telegram', 'import', 'webhook', 'api'
  severity TEXT DEFAULT 'error', -- 'error', 'warning', 'critical'
  
  -- Контекст
  org_id UUID REFERENCES organizations(id),
  user_id UUID,
  
  -- Данные ошибки
  error_message TEXT NOT NULL,
  error_code TEXT,
  stack_trace TEXT,
  request_path TEXT,
  request_method TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  
  -- Статус
  resolved BOOLEAN DEFAULT FALSE,
  resolved_at TIMESTAMPTZ,
  resolved_by UUID
);

CREATE INDEX idx_admin_error_logs_created ON admin_error_logs(created_at DESC);
CREATE INDEX idx_admin_error_logs_category ON admin_error_logs(category);
CREATE INDEX idx_admin_error_logs_org ON admin_error_logs(org_id);
```

#### 2. Сервис: `lib/services/errorLoggingService.ts`
```typescript
export async function logAdminError(params: {
  category: 'auth' | 'telegram' | 'import' | 'webhook' | 'api';
  severity?: 'error' | 'warning' | 'critical';
  errorMessage: string;
  errorCode?: string;
  stackTrace?: string;
  orgId?: string;
  userId?: string;
  requestPath?: string;
  requestMethod?: string;
  metadata?: Record<string, any>;
}): Promise<void>
```

#### 3. Интеграция в критические места:
- `app/api/telegram/webhook/route.ts` — ошибки webhook
- `app/api/auth/callback/route.ts` — ошибки auth
- `app/api/telegram/import-history/*/route.ts` — ошибки импорта
- `app/p/[org]/auth/page.tsx` — ошибки авторизации участников

#### 4. UI для суперадминов:
- Страница `/admin/errors` с таблицей ошибок
- Фильтры по категории, severity, org_id
- Возможность отметить как resolved

---

## 🔵 Задача 4: Подготовка Unisender Go (откладываем)

**Статус:** Отложено на следующий день  
**Причина:** Приоритет на AI-анализ и логгирование

---

## 📊 Порядок выполнения

| # | Задача | Время | Приоритет |
|---|--------|-------|-----------|
| 1 | Исправить баг AI-анализа (org_id → tg_chat_id) | 2-3h | 🔴 Critical |
| 2 | A. Добавить контекст ответов (reply_to) | 1h | 🟡 High |
| 3 | C. Добавить реакции как сигнал | 1h | 🟡 High |
| 4 | B. Добавить контекст треда | 1h | 🟢 Medium |
| 5 | Тестирование AI-анализа | 0.5h | 🔴 Critical |
| 6 | Логгирование (если время) | 2-3h | 🟢 Medium |

**Total:** 6-8 часов

---

## ✅ Критерии готовности (DoD)

- [ ] AI-анализ показывает корректное количество сообщений
- [ ] AI-анализ выполняется успешно для участников с сообщениями
- [ ] Контекст ответов (reply_to) включён в анализ
- [ ] Реакции используются как сигнал интересов
- [ ] Контекст треда добавлен (опционально)
- [ ] Качество анализа улучшилось (субъективная оценка)

---

## 🔗 Связанные файлы

```
lib/services/
├── participantEnrichmentService.ts  ← Основные изменения
├── enrichment/
│   └── openaiService.ts             ← Обновление промпта
└── errorLoggingService.ts           ← Новый файл (если время)

app/api/participants/[participantId]/
└── enrich-ai/route.ts               ← Проверить params

db/migrations/
└── 136_admin_error_logs.sql         ← Новый файл (если время)
```

---

**Last Updated:** 4 декабря 2025, 23:00  
**Author:** AI Assistant

