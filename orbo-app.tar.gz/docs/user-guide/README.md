# Документация пользователя Orbo

> Руководство по использованию платформы управления Telegram-сообществами

---

## 📚 Содержание

### 1. Начало работы

- [Регистрация и вход](./01-getting-started/registration.md)
- [Подключение Telegram-аккаунта](./01-getting-started/connect-telegram.md)
- [Создание первой организации](./01-getting-started/first-organization.md)

### 2. Telegram-группы

- [Какие боты и для чего](./02-telegram-groups/bots-overview.md)
- [Как добавить бота в группу](./02-telegram-groups/add-bot-to-group.md)
- [Подключение группы к организации](./02-telegram-groups/connect-groups.md)
- [Импорт истории сообщений](./02-telegram-groups/import-history.md)

### 3. Участники (CRM)

- [Профили участников](./03-participants-crm/profiles.md)
- [AI-анализ интересов](./03-participants-crm/ai-enrichment.md)
- [Поиск и фильтрация](./03-participants-crm/search-filters.md)
- [Импорт из WhatsApp](./03-participants-crm/whatsapp-import.md)

### 4. События

- [Создание события](./04-events/create-event.md)
- [Настройка формы регистрации](./04-events/registration-form.md)
- [Управление оплатами](./04-events/payments.md)
- [Публикация в Telegram](./04-events/telegram-publish.md)

### 5. Уведомления

- [Обзор правил уведомлений](./05-notifications/rules-overview.md)
- [AI-детекция негатива](./05-notifications/ai-negative.md)
- [Неотвеченные вопросы](./05-notifications/unanswered.md)
- [Зоны внимания](./05-notifications/attention-zones.md)

### 6. Организация и настройки

- [Настройки организации](./06-organization/settings.md)
- [Добавление администраторов](./06-organization/add-admins.md)
- [Синхронизация команды с Telegram](./06-organization/team-sync.md)

### 7. FAQ

- [Частые вопросы](./07-faq/faq.md)

---

## 🚀 Быстрый старт

### Шаг 1. Регистрация

Перейдите на [my.orbo.ru](https://my.orbo.ru) и создайте аккаунт.

### Шаг 2. Создание организации

Укажите название вашего сообщества.

### Шаг 3. Подключение Telegram

Привяжите свой Telegram-аккаунт для управления группами.

### Шаг 4. Добавление группы

Добавьте бота [@orbo_community_bot](https://t.me/orbo_community_bot) в вашу группу.

### Шаг 5. Готово!

Orbo начнёт собирать аналитику. Создавайте события, настраивайте уведомления, изучайте аудиторию.

---

## 🤖 Боты Orbo

| Бот | Username | Назначение |
|-----|----------|------------|
| Community Bot | [@orbo_community_bot](https://t.me/orbo_community_bot) | Сбор аналитики из групп |
| Assist Bot | [@orbo_assist_bot](https://t.me/orbo_assist_bot) | Уведомления и авторизация |
| Event Bot | [@orbo_event_bot](https://t.me/orbo_event_bot) | Регистрация на события (MiniApp) |

---

## 📞 Поддержка

Если что-то не работает или нужна помощь — обратитесь в поддержку через Telegram.

---

*Документация актуальна для версии Orbo 1.1*  
*Последнее обновление: Декабрь 2025*
