# Документация Orbo

Актуальная документация проекта после радикальной чистки (февраль 2025).

## 📋 Оглавление

### 🚀 Начало работы
- **[SETUP_GUIDE.md](./SETUP_GUIDE.md)** — полное руководство по развертыванию проекта
- **[COMPREHENSIVE_PRD.md](./COMPREHENSIVE_PRD.md)** — Product Requirements Document (PRD)

### 🤖 Telegram интеграция
- **[TELEGRAM_BOT_SETUP.md](./TELEGRAM_BOT_SETUP.md)** — настройка Telegram ботов
- **[TELEGRAM_WEBHOOK_SETUP.md](./TELEGRAM_WEBHOOK_SETUP.md)** — настройка вебхуков
- **[TELEGRAM_OWNERSHIP_ARCHITECTURE.md](./TELEGRAM_OWNERSHIP_ARCHITECTURE.md)** — архитектура владения группами
- **[TELEGRAM_ADMIN_SYNC_LOGIC_EXPLANATION.md](./TELEGRAM_ADMIN_SYNC_LOGIC_EXPLANATION.md)** — логика синхронизации админов
- **[TELEGRAM_CHAT_MIGRATION_GUIDE.md](./TELEGRAM_CHAT_MIGRATION_GUIDE.md)** — обработка миграции chat_id при создании супергрупп

### 👥 Участники и интерфейсы
- **[MEMBER_INTERFACE_GUIDE.md](./MEMBER_INTERFACE_GUIDE.md)** — гайд по интерфейсу участников

### 🗄️ База данных
- **[DATABASE_CLEANUP_COMPLETE_SUMMARY.md](./DATABASE_CLEANUP_COMPLETE_SUMMARY.md)** — итоговая сводка по очистке БД
- **[DATABASE_UNUSED_COLUMNS_AUDIT.md](./DATABASE_UNUSED_COLUMNS_AUDIT.md)** — аудит неиспользуемых колонок
- **[MIGRATION_42_CLEANUP_SUMMARY.md](./MIGRATION_42_CLEANUP_SUMMARY.md)** — сводка по очистке после миграции 42

### 👥 Участники
- **[PARTICIPANT_SCORING_LOGIC.md](./PARTICIPANT_SCORING_LOGIC.md)** — автоматический скоринг участников
- **[PARTICIPANT_SCORING_IMPLEMENTATION_SUMMARY.md](./PARTICIPANT_SCORING_IMPLEMENTATION_SUMMARY.md)** — сводка реализации

### 📊 Дашборд и аналитика
- **[DASHBOARD_ATTENTION_ZONES_FIX.md](./DASHBOARD_ATTENTION_ZONES_FIX.md)** — логика дашборда и зон внимания
- **[TELEGRAM_GROUPS_VERIFICATION_COLUMNS_ANALYSIS.md](./TELEGRAM_GROUPS_VERIFICATION_COLUMNS_ANALYSIS.md)** — анализ legacy столбцов верификации
- **[MESSAGE_STORAGE_UNIFICATION_PLAN.md](./MESSAGE_STORAGE_UNIFICATION_PLAN.md)** — план унификации хранения сообщений
- **[MESSAGE_STORAGE_UNIFICATION_COMPLETE.md](./MESSAGE_STORAGE_UNIFICATION_COMPLETE.md)** — ✅ завершённая унификация

### 🐛 Hotfixes
- **[HOTFIX_4_PROBLEMS_2025-11-06.md](./HOTFIX_4_PROBLEMS_2025-11-06.md)** — ✅ 4 критичных проблемы (audit log, импорт, webhook recovery)

### 📊 Стратегия и развитие (НОВОЕ — 1 ноября 2025)
- **[REVISED_ROADMAP_SOLO_2025-11-01.md](./REVISED_ROADMAP_SOLO_2025-11-01.md)** — ⭐ **ACTIVE ROADMAP** — 16-недельный план (solo-founder)
- **[PRIORITY_CHANGES_SUMMARY.md](./PRIORITY_CHANGES_SUMMARY.md)** — сводка изменений приоритетов
- **[STRATEGIC_ANALYSIS_2025-11-01.md](./STRATEGIC_ANALYSIS_2025-11-01.md)** — комплексный стратегический анализ
- **[Audit.md](./Audit.md)** — функциональный аудит платформы
- **[Gap-Analysis.md](./Gap-Analysis.md)** — анализ разрывов между стратегией и реализацией
- **[Roadmap2.md](./Roadmap2.md)** — 12-недельный roadmap (original, superseded)
- **[Tech-Notes.md](./Tech-Notes.md)** — технические заметки
- **[Runbook.md](./Runbook.md)** — операционное руководство
- **[Security_and_compliance.md](./Security_and_compliance.md)** — безопасность и compliance

---

## 🧹 История чистки

**Дата:** Февраль 2025  
**Удалено:** 
- 15 одноразовых SQL fix-скриптов из `db/`
- 165+ устаревших документов из `docs/`

**Что было удалено:**
- Все FIX/SUMMARY документы по историческим багам
- Промежуточные гайды по установке
- Многочисленные QUICK/ITERATION документы
- Документы по реализованным фичам (Import History, Auth fixes, Mobile UI, etc.)
- Папка `docs/db/` с устаревшими инструкциями

**Что осталось:**
- Актуальные setup guides
- Архитектурные документы
- Документация по Telegram интеграции
- Финальные сводки по очистке БД

---

## 📂 Структура проекта

```
orbo-1.1/
├── app/                    # Next.js App Router
├── components/             # React компоненты
├── lib/                    # Утилиты и сервисы
│   ├── services/          # Бизнес-логика
│   └── server/            # Server-side утилиты
├── db/                     # SQL миграции и инициализация
│   └── migrations/        # Нумерованные миграции
├── docs/                   # Документация (вы здесь)
├── memory-bank/            # Memory Bank (задачи, контекст, архив)
└── public/                 # Статические файлы
```

---

## 🔗 Полезные ссылки

- **Production:** https://app.orbo.ru
- **Supabase Project:** [Ссылка на Supabase Dashboard]
- **Vercel Project:** [Ссылка на Vercel]
- **Telegram Bots:**
  - `@orbo_community_bot` — управление группами
  - `@orbo_assistant_bot` — авторизация участников

---

## 💡 Принципы работы с документацией

1. **Не создавать FIX-документы** для каждого бага — фиксить сразу в коде
2. **Не хранить промежуточные SUMMARY** — оставлять только финальные
3. **Устаревшие гайды удалять** — поддерживать один актуальный SETUP_GUIDE
4. **Архитектурные доки обновлять** при изменении логики

---

**Последнее обновление:** 4 ноября 2025

