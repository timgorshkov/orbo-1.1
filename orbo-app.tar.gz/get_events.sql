SELECT id, title FROM events WHERE status = 'published' LIMIT 3;
