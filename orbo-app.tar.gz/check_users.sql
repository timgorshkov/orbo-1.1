SELECT COUNT(*) as users_count FROM public.users;
SELECT COUNT(*) as qual_count FROM user_qualification_responses;
SELECT * FROM get_qualification_summary();
