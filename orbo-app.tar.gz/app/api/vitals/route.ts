import { NextRequest, NextResponse } from 'next/server';
import { createAPILogger } from '@/lib/logger';

export const dynamic = 'force-dynamic';

// Server-side deduplication cache (simple in-memory, cleared periodically)
const recentMetricIds = new Set<string>();
let lastCleanup = Date.now();
const CLEANUP_INTERVAL = 60000; // 1 minute
const MAX_CACHED_IDS = 1000;

interface VitalsPayload {
  name: string;
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  level: 'info' | 'warn' | 'error';
  pathname: string;
  id: string;
  timestamp: string;
}

/**
 * API endpoint для получения Web Vitals метрик от клиента
 * 
 * Логирует метрики производительности:
 * - info: нормальные значения
 * - warn: значения выше порогов (например LCP > 4s)
 * - error: критически плохие значения (например LCP > 10s)
 */
export async function POST(req: NextRequest) {
  const logger = createAPILogger(req, { endpoint: 'api/vitals' });
  
  try {
    const payload: VitalsPayload = await req.json();
    
    const { name, value, rating, level, pathname, id, timestamp } = payload;
    
    // Server-side deduplication
    const now = Date.now();
    if (now - lastCleanup > CLEANUP_INTERVAL || recentMetricIds.size > MAX_CACHED_IDS) {
      recentMetricIds.clear();
      lastCleanup = now;
    }
    
    // Skip if already received this metric ID
    if (recentMetricIds.has(id)) {
      return NextResponse.json({ ok: true, deduplicated: true });
    }
    recentMetricIds.add(id);
    
    // Логируем в зависимости от уровня
    const logData = {
      metric: name,
      value,
      rating,
      pathname,
      metric_id: id,
      client_timestamp: timestamp,
    };
    
    // CLS - это score (не время), показываем без "ms"
    const unit = name === 'CLS' ? '' : 'ms';
    const valueStr = name === 'CLS' ? value.toFixed(3) : String(Math.round(value));
    
    // Superadmin pages: log to Dozzle only (info level), don't send to Hawk
    const isSuperadmin = pathname.startsWith('/superadmin');
    
    if (isSuperadmin) {
      // Info level won't trigger Hawk, but visible in Dozzle
      logger.info(logData, `Web Vitals [superadmin]: ${name}=${valueStr}${unit} on ${pathname}`);
    } else if (level === 'error') {
      logger.error(logData, `Web Vitals CRITICAL: ${name}=${valueStr}${unit} on ${pathname}`);
    } else if (level === 'warn') {
      logger.warn(logData, `Web Vitals SLOW: ${name}=${valueStr}${unit} on ${pathname}`);
    } else {
      logger.debug(logData, `Web Vitals: ${name}=${valueStr}${unit}`);
    }
    
    return NextResponse.json({ ok: true });
  } catch (error) {
    // Не логируем ошибки парсинга - это может быть спам
    return NextResponse.json({ ok: false }, { status: 400 });
  }
}

