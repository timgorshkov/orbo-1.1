import { NextResponse } from 'next/server';
import { participantMatcher } from '@/lib/services/participants/matcher';
import { createAdminServer } from '@/lib/server/supabaseServer';
import { createAPILogger } from '@/lib/logger';
import { getUnifiedUser } from '@/lib/auth/unified-auth';

async function ensureOrgAccess(orgId: string) {
  const user = await getUnifiedUser();

  if (!user) {
    return { error: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) };
  }

  const adminSupabase = createAdminServer();
  const { data: membership } = await adminSupabase
    .from('memberships')
    .select('role')
    .eq('org_id', orgId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (!membership) {
    return { error: NextResponse.json({ error: 'Access denied' }, { status: 403 }) };
  }

  return { user };
}

export async function POST(request: Request) {
  const logger = createAPILogger(request, { endpoint: '/api/participants/check-duplicates' });
  let orgId: string | undefined;
  try {
    const payload = await request.json();
    orgId = payload?.orgId as string | undefined;
    const currentParticipantId = payload?.currentParticipantId as string | undefined;

    if (!orgId) {
      return NextResponse.json({ error: 'Missing orgId' }, { status: 400 });
    }

    const access = await ensureOrgAccess(orgId);
    if ('error' in access) {
      return access.error;
    }

    const matches = await participantMatcher.findMatches({
      orgId,
      email: payload?.email,
      phone: payload?.phone,
      username: payload?.username,
      tg_user_id: payload?.tg_user_id,
      full_name: payload?.full_name,
      first_name: payload?.first_name,
      last_name: payload?.last_name
    });

    // Исключаем текущего участника из результатов
    const filteredMatches = currentParticipantId 
      ? matches.filter(match => match.id !== currentParticipantId)
      : matches;

    return NextResponse.json({ matches: filteredMatches });
  } catch (error: any) {
    logger.error({ 
      error: error?.message || String(error),
      stack: error?.stack,
      org_id: orgId || 'unknown'
    }, 'Error checking participant duplicates');
    return NextResponse.json({ error: error?.message || 'Internal server error' }, { status: 500 });
  }
}

