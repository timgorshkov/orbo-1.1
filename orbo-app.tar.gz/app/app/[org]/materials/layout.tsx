export default function MaterialsLayout({ children }: { children: React.ReactNode }) {
  return children
}
