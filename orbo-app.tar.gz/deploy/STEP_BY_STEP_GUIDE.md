# Пошаговая инструкция по развёртыванию Orbo на Selectel

Эта инструкция написана для пользователей с минимальным DevOps-опытом. Каждый шаг детально описан.

## Содержание

1. [Подготовка локальной машины (Windows)](#1-подготовка-локальной-машины-windows)
2. [Первое подключение к серверу](#2-первое-подключение-к-серверу)
3. [Настройка безопасности сервера](#3-настройка-безопасности-сервера)
4. [Установка Docker](#4-установка-docker)
5. [Настройка Selectel S3](#5-настройка-selectel-s3)
6. [Настройка DNS](#6-настройка-dns)
7. [Развёртывание приложения](#7-развёртывание-приложения)
8. [Настройка SSL](#8-настройка-ssl)
9. [Проверка работоспособности](#9-проверка-работоспособности)
10. [Настройка бэкапов](#10-настройка-бэкапов)

---

## 1. Подготовка локальной машины (Windows)

### 1.1 Генерация SSH-ключа

Откройте **PowerShell** (найдите через поиск Windows) и выполните:

```powershell
# Создаём папку для ключей (если не существует)
mkdir -Force "$env:USERPROFILE\.ssh"

# Генерируем SSH-ключ
ssh-keygen -t ed25519 -C "orbo-selectel" -f "$env:USERPROFILE\.ssh\selectel_key"
```

Когда попросит **passphrase** — нажмите Enter (пустой пароль) или придумайте пароль (придётся вводить при каждом подключении).

**Результат:** созданы два файла:
- `C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.ssh\selectel_key` — приватный ключ (НИКОМУ не передавайте!)
- `C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.ssh\selectel_key.pub` — публичный ключ (его копируем на сервер)

### 1.2 Настройка SSH Config

Создайте/отредактируйте файл конфигурации SSH:

```powershell
notepad "$env:USERPROFILE\.ssh\config"
```

Вставьте (замените `YOUR_SERVER_IP` на реальный IP сервера Selectel):

```
Host selectel-orbo
    HostName YOUR_SERVER_IP
    User deploy
    IdentityFile ~/.ssh/selectel_key
    ServerAliveInterval 60
```

**Сохраните** файл (Ctrl+S) и закройте блокнот.

### 1.3 Установка дополнительных инструментов

Для удобной работы рекомендуется установить:

```powershell
# Установите Scoop (менеджер пакетов для Windows)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
irm get.scoop.sh | iex

# Установите rsync и s3cmd
scoop install git
scoop install s3cmd
```

---

## 2. Первое подключение к серверу

### 2.1 Подключение по паролю

IP-адрес сервера и пароль от root вы получили от Selectel (обычно на email).

```powershell
# Подключаемся (введите пароль когда попросит)
ssh root@YOUR_SERVER_IP
```

### 2.2 Копирование SSH-ключа на сервер

**Важно:** Выполните это ДО отключения входа по паролю!

В **новом** окне PowerShell (на локальной машине):

```powershell
# Показать содержимое публичного ключа
type "$env:USERPROFILE\.ssh\selectel_key.pub"
```

Скопируйте весь вывод (начинается с `ssh-ed25519...`).

В SSH-сессии на сервере:

```bash
# Создаём файл для ключей
mkdir -p ~/.ssh
nano ~/.ssh/authorized_keys
```

Вставьте скопированный ключ, затем:
- Ctrl+X (выход)
- Y (сохранить)
- Enter (подтвердить имя файла)

### 2.3 Проверка подключения по ключу

Закройте SSH-сессию (`exit`) и подключитесь заново без пароля:

```powershell
ssh root@YOUR_SERVER_IP -i "$env:USERPROFILE\.ssh\selectel_key"
```

Если подключились без запроса пароля — всё работает!

---

## 3. Настройка безопасности сервера

Подключитесь к серверу (ssh root@...) и выполните:

### 3.1 Обновление системы

```bash
apt update && apt upgrade -y
```

### 3.2 Установка необходимых пакетов

```bash
apt install -y ca-certificates curl gnupg git htop vim ufw fail2ban
```

### 3.3 Создание пользователя для деплоя

```bash
# Создаём пользователя deploy
adduser --disabled-password --gecos "" deploy
usermod -aG sudo deploy

# Разрешаем sudo без пароля
echo "deploy ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/deploy
chmod 440 /etc/sudoers.d/deploy

# Копируем SSH-ключи для нового пользователя
mkdir -p /home/deploy/.ssh
cp /root/.ssh/authorized_keys /home/deploy/.ssh/
chown -R deploy:deploy /home/deploy/.ssh
chmod 700 /home/deploy/.ssh
chmod 600 /home/deploy/.ssh/authorized_keys
```

### 3.4 Отключение входа по паролю

**ВАЖНО:** Убедитесь, что вход по ключу работает, прежде чем отключать пароль!

```bash
# Редактируем конфигурацию SSH
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config

# Перезапускаем SSH
systemctl restart sshd
```

### 3.5 Настройка файервола

```bash
# Сбрасываем правила
ufw --force reset

# Настраиваем
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp    # SSH
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS

# Включаем
ufw enable

# Проверяем статус
ufw status verbose
```

### 3.6 Настройка fail2ban

```bash
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 1h
findtime = 10m
maxretry = 5

[sshd]
enabled = true
maxretry = 3
EOF

systemctl enable fail2ban
systemctl restart fail2ban
```

**Проверка:** Теперь вы можете подключаться только по ключу:

```powershell
# На локальной машине
ssh selectel-orbo  # Должно работать (используется конфиг)
```

---

## 4. Установка Docker

Выполните на сервере под пользователем **deploy**:

```bash
# Переключаемся на deploy
su - deploy

# Или подключаемся заново
# ssh selectel-orbo
```

### 4.1 Установка Docker

```bash
# Добавляем GPG-ключ Docker
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Добавляем репозиторий
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Устанавливаем Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Добавляем себя в группу docker (чтобы не писать sudo)
sudo usermod -aG docker deploy

# ВАЖНО: выйдите и войдите заново для применения групп
exit
```

После переподключения:

```bash
# Проверяем
docker --version
docker compose version
docker run hello-world
```

---

## 5. Настройка Selectel S3

### 5.1 Создание контейнера (bucket)

1. Откройте [my.selectel.ru](https://my.selectel.ru)
2. В левом меню: **Объектное хранилище**
3. Нажмите **Создать контейнер**
4. Заполните:
   - Имя: `orbo-materials`
   - Регион: `ru-1` (или ближайший к серверу)
   - Класс хранения: `Standard`
   - Тип доступа: **Приватный**
5. Нажмите **Создать**

### 5.2 Создание сервисного пользователя

1. В левом меню: **Управление** → **Сервисные пользователи**
2. Нажмите **Добавить пользователя**
3. Заполните:
   - Имя пользователя: `orbo-s3-user`
   - Роль: **Администратор объектного хранилища**
4. После создания нажмите на пользователя
5. Создайте **EC2 credentials**:
   - Нажмите **Добавить ключ**
   - Скопируйте и сохраните **Access Key ID** и **Secret Access Key**

⚠️ **Secret Key показывается только один раз!** Сохраните его надёжно.

### 5.3 Настройка s3cmd на локальной машине

```powershell
# Запустите скрипт настройки
cd "C:\Cursor WS\orbo-1.1.1\orbo-1.1\deploy\scripts"
.\s3cfg-setup.ps1
```

Или вручную создайте файл `C:\Users\ВАШ_ПОЛЬЗОВАТЕЛЬ\.s3cfg`:

```ini
[default]
access_key = ВАШ_ACCESS_KEY
secret_key = ВАШ_SECRET_KEY
host_base = s3.storage.selcloud.ru
host_bucket = %(bucket)s.s3.storage.selcloud.ru
use_https = True
```

Проверьте:

```powershell
s3cmd ls
# Должен показать: s3://orbo-materials
```

---

## 6. Настройка DNS

### 6.1 Добавление DNS-записей

В панели управления вашим доменом (там где покупали домен):

| Тип | Имя | Значение | TTL |
|-----|-----|----------|-----|
| A | @ | IP_СЕРВЕРА | 3600 |
| A | www | IP_СЕРВЕРА | 3600 |

Пример для домена `orbo.ru`:
- `@` означает сам домен `orbo.ru`
- `www` создаст `www.orbo.ru`

### 6.2 Проверка DNS

DNS-записи применяются от 5 минут до 48 часов. Проверить можно:

```powershell
# На локальной машине
nslookup yourdomain.ru
```

Должен вернуть IP вашего сервера.

---

## 7. Развёртывание приложения

### 7.1 Создание структуры на сервере

```bash
# Подключаемся к серверу
ssh selectel-orbo

# Создаём структуру папок
mkdir -p ~/orbo/{app,nginx/logs,data/postgres,data/certbot,scripts,backups}
```

### 7.2 Копирование файлов

На **локальной машине** в PowerShell:

```powershell
# Переходим в папку проекта
cd "C:\Cursor WS\orbo-1.1.1\orbo-1.1"

# Копируем файлы деплоя
scp deploy/docker-compose.yml selectel-orbo:~/orbo/
scp deploy/Dockerfile selectel-orbo:~/orbo/app/
scp deploy/nginx/nginx.conf selectel-orbo:~/orbo/nginx/
scp deploy/env.example selectel-orbo:~/orbo/.env
scp deploy/scripts/*.sh selectel-orbo:~/orbo/scripts/

# Делаем скрипты исполняемыми
ssh selectel-orbo "chmod +x ~/orbo/scripts/*.sh"
```

### 7.3 Настройка переменных окружения

На сервере:

```bash
cd ~/orbo
nano .env
```

Замените все placeholder-значения на реальные:

```bash
# Сгенерируйте пароль БД
openssl rand -base64 32
# Скопируйте результат в POSTGRES_PASSWORD

# Сгенерируйте webhook secret
openssl rand -hex 32
# Скопируйте результат в TELEGRAM_WEBHOOK_SECRET
```

**Ключевые переменные для заполнения:**
- `POSTGRES_PASSWORD` — сгенерированный пароль
- `NEXT_PUBLIC_APP_URL` — ваш домен (https://yourdomain.ru)
- `SELECTEL_ACCESS_KEY` — из шага 5.2
- `SELECTEL_SECRET_KEY` — из шага 5.2
- `TELEGRAM_BOT_TOKEN` — от @BotFather
- `SUPABASE_*` — текущие credentials (временно, для миграции)

### 7.4 Копирование исходного кода

На **локальной машине**:

```powershell
# Через Git Bash или WSL (rsync быстрее)
rsync -avz --progress --delete `
    --exclude 'node_modules' `
    --exclude '.next' `
    --exclude '.git' `
    --exclude 'deploy' `
    --exclude '.env*' `
    ./ deploy@selectel-orbo:~/orbo/app/
```

Или через scp (медленнее):

```powershell
scp -r . selectel-orbo:~/orbo/app/
```

### 7.5 Обновление nginx.conf

На сервере замените `YOUR_DOMAIN.ru` на ваш домен:

```bash
cd ~/orbo
sed -i 's/YOUR_DOMAIN\.ru/my.orbo.ru/g' nginx/nginx.conf
```

### 7.6 Запуск PostgreSQL

```bash
cd ~/orbo
docker compose up -d postgres

# Ждём ~15 секунд инициализации
sleep 15

# Проверяем
docker compose logs postgres
docker exec orbo_postgres pg_isready -U orbo
```

### 7.7 Запуск приложения

```bash
# Сборка образа (может занять 5-10 минут)
docker compose build app

# Запуск
docker compose up -d app

# Проверяем логи
docker compose logs -f app
# Ctrl+C чтобы выйти из логов
```

---

## 8. Настройка SSL

⚠️ **Выполняйте только после настройки DNS** (домен должен указывать на IP сервера)

### 8.1 Запуск скрипта SSL

```bash
cd ~/orbo
./scripts/ssl-setup.sh yourdomain.ru your@email.com
```

Скрипт автоматически:
1. Создаст временный nginx-конфиг
2. Получит сертификат от Let's Encrypt
3. Настроит nginx с SSL
4. Настроит автообновление сертификата

### 8.2 Проверка SSL

```bash
# Проверяем что всё работает
curl -I https://yourdomain.ru
```

Должен вернуть `HTTP/2 200` или `301/302` redirect.

---

## 9. Проверка работоспособности

### 9.1 Проверка контейнеров

```bash
docker compose ps
```

Все сервисы должны быть в статусе `Up` и `healthy`.

### 9.2 Проверка логов

```bash
# Логи приложения
docker compose logs app

# Логи nginx
docker compose logs nginx

# Логи базы данных
docker compose logs postgres
```

### 9.3 Тестирование API

```bash
# Health check
curl http://localhost:3000/api/health

# Через nginx (если SSL настроен)
curl https://yourdomain.ru/api/health
```

### 9.4 Проверка в браузере

Откройте `https://yourdomain.ru` — должна открыться страница приложения.

---

## 10. Настройка бэкапов

### 10.1 Тестовый бэкап

```bash
cd ~/orbo
./scripts/backup.sh
```

### 10.2 Автоматические бэкапы

```bash
# Открываем crontab
crontab -e
```

Добавьте строку (бэкап каждый день в 3:00):

```
0 3 * * * /home/deploy/orbo/scripts/backup.sh >> /home/deploy/orbo/scripts/backup.log 2>&1
```

### 10.3 Проверка бэкапов

```bash
ls -la ~/orbo/backups/
```

---

## Частые проблемы и решения

### Не могу подключиться по SSH

1. Проверьте IP-адрес сервера
2. Убедитесь, что ключ правильный: `ssh -v selectel-orbo`
3. Проверьте файервол: `sudo ufw status`

### Приложение не запускается

```bash
# Смотрим логи
docker compose logs app

# Проверяем переменные
docker compose exec app env | grep -E "(DATABASE|SUPABASE)"
```

### Ошибка SSL/DNS

1. Убедитесь, что DNS настроен: `nslookup yourdomain.ru`
2. Подождите распространения DNS (до 48 часов)
3. Проверьте nginx: `docker compose exec nginx nginx -t`

### База данных недоступна

```bash
# Проверяем контейнер
docker compose ps postgres

# Смотрим логи
docker compose logs postgres

# Проверяем подключение
docker exec -it orbo_postgres psql -U orbo -d orbo
```

---

## Полезные команды

```bash
# Перезапуск приложения
docker compose restart app

# Пересборка и перезапуск
docker compose build app && docker compose up -d app

# Остановка всего
docker compose down

# Очистка Docker (освобождает место)
docker system prune -a

# Просмотр ресурсов
docker stats
htop

# Место на диске
df -h
```

---

## Контакты поддержки

- Selectel: support@selectel.ru или через панель
- Документация Selectel: docs.selectel.ru

---

**Готово!** Ваше приложение развёрнуто на Selectel. 🎉






