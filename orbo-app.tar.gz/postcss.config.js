module.exports = {
  plugins: {
    tailwindcss: {}, // Правильная запись
    autoprefixer: {},
  },
}
