export const getcourseConnectors = {
  baseUrlPlaceholder: 'https://example.getcourse.ru',
  docsUrl: 'https://getcourse.ru/api'
};

